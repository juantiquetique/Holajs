// const nombre = document.getElementsByClassName("parrafo");
// const nombre = document.querySelectorAll(".parrafo");
// nombre.textContent = "Pepito Pérez"

// const nombre = document.getElementById("nombre");
// const num = document.getElementById("num");

// let nuevoNombre = prompt("Ingrese un nombre");

// nombre.textContent = nuevoNombre;

// let numero =prompt("Ingrese un número");
// let  a = 2;
// let suma = parseInt(numero) + a;
// // alert(suma);

// num.textContent = suma;
// console.log(nombre);

// TODO: consultar los operadores relacionales ==, ===, !=, !==
// TODO: consultar los operadores logicos para AND, OR, NOT
